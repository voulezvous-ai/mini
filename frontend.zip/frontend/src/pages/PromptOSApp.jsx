import React from 'react';

export default function PromptOSApp() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>PromptOS</h1>
      <p>Interface de orquestração e comandos (simulação estilo ChatGPT).</p>
    </div>
  );
}