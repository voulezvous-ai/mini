# Documentação do PromptOS

Esta documentação foi gerada automaticamente com Sphinx.

## Gerando a documentação localmente

1. Instale as dependências:
   ```bash
   pip install sphinx
   ```

2. Navegue até a pasta docs e execute:
   ```bash
   make html
   ```

A documentação estará disponível em docs/_build/html/index.html.