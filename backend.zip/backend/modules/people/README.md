# Mini Final

Sistema unificado com backend e frontend prontos para produção.